﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GolAPI.Models;

namespace GolAPI.Controllers
{
    [RoutePrefix("Api/Airplane")]
    public class AirplaneController : ApiController
    {
        DBTestGOLEntities objEnt = new DBTestGOLEntities();

        [HttpGet]
        [Route("AllAirplanes")]
        public IQueryable<Airplane> GetAirplane()
        {
            try
            {
                return objEnt.Airplanes;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("GetAirplanesByID/{aiplaneID}")]
        public IHttpActionResult GetAirplaneByID(int airplaneID)
        {
            Airplane objAirplane = new Airplane();

            try
            {
                objAirplane = objEnt.Airplanes.Find(airplaneID);
                if (objAirplane == null)
                    return NotFound();
            }
            catch (Exception)
            {
                throw;
            }

            return Ok(objAirplane);
        }

        [HttpPost]
        [Route("InsertAirplanes")]
        public IHttpActionResult PostAirplane(Airplane data)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                objEnt.Airplanes.Add(data);
                objEnt.SaveChanges();
            }
            catch(Exception)
            {
                throw;
            }

            return Ok(data);
        }

        [HttpPut]
        [Route("UpdateAirplanes")]
        public IHttpActionResult PutAirplane(Airplane airplane)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                Airplane objAirplane = new Airplane();
                objAirplane = objEnt.Airplanes.Find(airplane.Airplane_ID);

                if (objAirplane != null)
                {
                    objAirplane.CodigoAviao = airplane.CodigoAviao;
                    objAirplane.Modelo = airplane.Modelo;
                    objAirplane.Passageiros = airplane.Passageiros;
                    objAirplane.DataCriacao = airplane.DataCriacao;
                }

                int i = this.objEnt.SaveChanges();
            }
            catch(Exception)
            {
                throw;
            }

            return Ok(airplane);
        }

        [HttpDelete]
        [Route("DeleteAirplane")]
        public IHttpActionResult DeleteAirplane(int id)
        {
            Airplane objAirplane = objEnt.Airplanes.Find(id);
            if (objAirplane == null)
                return NotFound();

            objEnt.Airplanes.Remove(objAirplane);
            objEnt.SaveChanges();

            return Ok(objAirplane);

        }
    
    }
}
